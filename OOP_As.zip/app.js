const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if(entry.isIntersecting) {
            entry.target.classList.add('show');
        } else {
            entry.target.classList.remove('show');
        }
    });
});


const hiddenItems = document.querySelectorAll('.hidden');
hiddenItems.forEach((el) => observer.observe(el));

Vue.directive('uppercase', {
    bind(el) {
      el.style.cursor = 'pointer';
      el.addEventListener('input', () => {
        const text = el.value;
        el.value = text.toUpperCase();
      });
    }
  });
  
  new Vue({
    el: '#app1'
  });


  let arr = [
    { content: 'Go for run', completed: false },
    { content: 'Read book', completed: false }
  ];
  
  function changeState(i) {
    if(arr[i].completed == false) {
      event.target.style.textDecoration = 'line-through';
      arr[i].completed = true;
    } else {
      event.target.style.textDecoration = 'none';
      arr[i].completed = false;
    }
  }
  
    Vue.directive('list', {
      bind(el, binding) {
        let action = '';
        const bool = false;
  
        function disp() {
  
          const ul = document.getElementById('umain');
  
          if(action != '') {
            let obj1 = { content: action, completed: bool };
            action = '';
    
            binding.value.push(obj1);
          }
    
        let i;
        s='';
        for(i=0; i<binding.value.length; i++)
          s+=`<li onclick="changeState(${i})" style="cursor: pointer">${binding.value[i].content}</li>`;
  
        ul.innerHTML = s;
  
      }
  
        document.addEventListener('DOMContentLoaded', disp);
  
        document.getElementById('btn').addEventListener('click',() => {
          const text = document.getElementById('inp').value;
          action += text;
          disp();
        });
      }
    });
    
    new Vue({
      el: '#app2',
    });


    
Vue.directive('getdate', {
    bind(el) {
      el.oninput = () => {
          const text = el.value;
          const options = { year: 'numeric', month: 'long', day: 'numeric' };
          const fdate = new Date(text).toLocaleDateString('en-US', options);  
  
          const p1 = document.getElementById('p1');
          p1.innerText =` ${fdate}`;
        }
      }
  });
  
  new Vue({
    el: '#inp1'
  });